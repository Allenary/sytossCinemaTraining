package com.sytoss.training.cinema.domainservice;

public interface ISplitStategy {

  String[] splitByCommas(String rowToParse);
}
