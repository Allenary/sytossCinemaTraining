package com.sytoss.training.cinema.exception;

public class CsvStringParseException extends RuntimeException {

  public CsvStringParseException(String message) {
    super(message);
  }

}
