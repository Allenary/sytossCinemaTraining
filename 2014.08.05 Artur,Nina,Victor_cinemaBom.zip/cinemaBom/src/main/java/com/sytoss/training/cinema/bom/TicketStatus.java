package com.sytoss.training.cinema.bom;

public enum TicketStatus {
	ENABLE, RESERVED, SOLD, NOT_FOR_SALE;

}
