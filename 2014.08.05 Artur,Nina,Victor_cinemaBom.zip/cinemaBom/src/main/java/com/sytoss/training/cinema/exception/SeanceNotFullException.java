package com.sytoss.training.cinema.exception;

public class SeanceNotFullException extends CinemaException {

  public SeanceNotFullException(String message) {
    super(message);
  }

}
