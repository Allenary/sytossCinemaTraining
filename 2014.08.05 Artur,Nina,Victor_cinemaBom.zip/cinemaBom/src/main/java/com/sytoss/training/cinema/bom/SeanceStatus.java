package com.sytoss.training.cinema.bom;

public enum SeanceStatus {
	OPENED, CLOSED, CANCELED
}
