package com.sytoss.training.cinema.exception;

public class SeanceChangeStateException extends RuntimeException {

  public SeanceChangeStateException(String message) {
    super(message);
  }
}
