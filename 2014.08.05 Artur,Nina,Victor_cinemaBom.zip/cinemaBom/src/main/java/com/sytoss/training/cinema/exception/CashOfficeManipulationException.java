package com.sytoss.training.cinema.exception;

public class CashOfficeManipulationException extends RuntimeException {

  public CashOfficeManipulationException(String message) {
    super(message);
  }
}
