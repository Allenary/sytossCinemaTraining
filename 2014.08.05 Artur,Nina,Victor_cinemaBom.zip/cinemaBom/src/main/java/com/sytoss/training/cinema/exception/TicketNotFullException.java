package com.sytoss.training.cinema.exception;

public class TicketNotFullException extends CinemaException {

  public TicketNotFullException(String message) {
    super(message);
  }

}
